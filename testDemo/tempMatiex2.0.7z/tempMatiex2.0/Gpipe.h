#ifndef GPIPE_H
#define GPIPE_H
#endif

void Gpipe(char* m);
